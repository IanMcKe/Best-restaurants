-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 20, 2015 at 10:45 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food`
--
CREATE DATABASE IF NOT EXISTS `food` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `food`;

-- --------------------------------------------------------

--
-- Table structure for table `cuisines`
--

CREATE TABLE IF NOT EXISTS `cuisines` (
  `type` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cuisines`
--

INSERT INTO `cuisines` (`type`, `id`) VALUES
('Chinese', 7),
('Mexican', 8),
('Ethiopian', 9),
('Italian', 10),
('Japanese ', 11),
('French', 12),
('Vegan', 13),
('Seafood', 14);

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE IF NOT EXISTS `restaurants` (
  `name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `cuisine_id` bigint(20) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`name`, `location`, `description`, `price`, `cuisine_id`, `id`) VALUES
('Dragonwell Bistro', '735 Southwest 1st Avenue, Portland, OR 97204', 'Contemporary Chinese bistro serves a range of traditional fare in a high-ceilinged open dining room.', '$$', 7, 11),
('Chens Good Taste Restaurant', '18 NW 4th Ave, Portland, OR 97209', 'Simple dishes with roasted meats star at this unassuming, fluorescent-lit spot for classic Chinese.', '$$', 7, 12),
('Golden Horse Seafood Restaurant', '238 NW 4th Ave, Portland, OR 97209', 'Banquet hall setting for hearty portions of classic Chinese fare in a family friendly, basic room.', '$$', 7, 13),
('Santeria', '703 SW Ankeny St, Portland, OR 97205', 'Unassuming Mexican restaurant with late-night hours & many options for vegetarians & vegans.', '$', 8, 14),
('Mazatlan Mexican Restaurant', '2050 SW Morrison St, Portland, OR 97205', 'Colorful eatery with patio offers fresh fare & large margaritas, plus music & karaoke on weekends.', '$$', 8, 15),
('Mi Mero Mole', '32 NW 5th Ave, Portland, OR 97209', 'Mexico City-inspired street food & innovative stews meet cocktails at this hip, lively eatery.', '$$$$', 8, 16),
('Queen of Sheba Ethiopian Restaurant', '2413 NE Martin Luther King Jr Blvd, Portland, OR 97208', 'Staple for family-style African dishes, including vegetarian options, housed in simple surrounds.', '$$', 9, 17),
('Sengatera Ethiopian Restaurant', '3833 NE Martin Luther King Jr Blvd, Portland, OR 97212', 'Festive selection for Ethiopian eats seasoned with indigenous spices, plus live music on weekends.', '$$', 9, 18),
('Piazza Italia', '1129 NW Johnson St, Portland, OR 97209', 'Traditional, old-world Italian fare in a small, cheery spot with soccer decor on walls & on the TV.', '$$', 10, 19),
('Gildas Italian Restaurant', '1601 SW Morrison St, Portland, OR 97205', 'Happening, mural-adorned spot drawing crowds with its ample portions of traditional Italian fare.', '$$', 10, 20),
('Pazzo Ristorante', '627 SW Washington St, Portland, OR 97205', 'Elegant eatery at Hotel Vintage Plaza serving Northern Italian classics, with bar & attached bakery.', '$$$', 10, 21),
('Mama Mia Trattoria', '439 SW 2nd Ave, Portland, OR 97204', 'An 1886 building houses an elegant restaurant with a lounge, happy hour & menu of Italian standards.', '$$', 10, 22),
('Shigezo', '910 SW Salmon St, Portland, OR 97205', 'Ramen, skewers & other Japanese pub fare, plus sake, in restaurant with a variety of seating styles.', '$$', 11, 23),
('Tanuki', '8029 SE Stark St, Portland, OR 97215', '21+ eatery & bar serving Japanese- & Korean-inflected fare in roomy, dimly lit digs with pinball.', '$$$', 11, 24),
('Beast', '5425 NE 30th Ave, Portland, OR 97211', 'Adventurous, meat-heavy fixed-price meals with no substitutions are served at communal tables.', '$$$$', 12, 25),
('LePigeon', '738 E Burnside St, Portland, OR 97214', 'Rotating menu of creative French-inspired fare served at communal tables or the bar in a snug room.', '$$$', 12, 26),
('Little Bird', '219 SW 6th Ave, Portland, OR 97204', 'Eclectic, inventive French bistro fare served in a sexy spot with red banquettes & mezzanine level.', '$$', 12, 27),
('Prasad', '925 NW Davis St, Portland, OR 97209', 'Counter-serve veggie & gluten-free cafe inside Yoga Pearl serving rice bowls, smoothies & raw food.', '$$', 13, 28),
('Blossoming Lotus', '1713 NE 15th Ave, Portland, OR 97212', 'Organic vegan fusion dishes, including some raw foods, served in a casual, stylish room with a bar.', '$$', 13, 29),
('Cabezon Restaurant', '5200 NE Sacramento St, Portland, OR 97213', 'Daily seafood dishes & a broad wine list served in a wooden-raftered cafe with a small fish counter.', '$$', 14, 30),
('Portland Seafood Co.', '205 Place, 9722 SE Washington St, Portland, OR 97216', 'Hearty dishes such as crab buckets, oysters & other house seafood specials in a casual dining room.', '$$', 14, 31);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `user` varchar(255) DEFAULT NULL,
  `stars` int(11) DEFAULT NULL,
  `headline` varchar(255) DEFAULT NULL,
  `body` varchar(255) DEFAULT NULL,
  `restaurant_id` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`user`, `stars`, `headline`, `body`, `restaurant_id`, `id`) VALUES
('Gustavo Avendaño Estepa', 5, 'So Good', 'Delicious Chinese food! Definitely try to go to the Happy Hour! Excellent prices and good food!', 11, 18),
('Erik Finley', 5, 'Really Good', 'Try the Happy Hour; great prices and nice decor.  I had lunch the day before; it got PACKED....probably because the food was excellent.  I liked how the cooked vegetables still had a little snap to them; everything seemed super fresh and so tasty.', 11, 19),
('babygirl6969', 1, 'Meh', 'Cant Even', 11, 20),
('Abraham Rissa', 4, 'Nice', 'Nicely done Derek tibs. Very nice people entertaining, polite funy. ', 18, 21),
('Wendwossen Alemayehu', 5, 'Authentic', 'True Ethiopian hospitality, testy food, specially tibs and nice atmosphere. Loved it.', 18, 22),
('ianisacoolguy', 5, 'Get the お任せ', 'It is crazy good.  Be careful with their zombies though, they will force you to bus home (not necessarily a bad thing)', 24, 23),
('Linda Gross', 4, 'YUM!!!!', 'Nice place to go for local cuisine. YUM!!!!', 31, 24),
('keasmea', 1, 'Dry and Rubbery', 'Lobster was dry and rubbery.  I had a Mojito and it was so sweet I sent it back to be remade. It came back even sweeter so I just cancelled it. ', 31, 25),
('Cynthia Bauman', 5, 'Good Food', 'Came at happy hour. Quick friendly service. Good food. We were simple. Really liked it. Homemade chips were so nice to see and good', 31, 26);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cuisines`
--
ALTER TABLE `cuisines`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cuisines`
--
ALTER TABLE `cuisines`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
